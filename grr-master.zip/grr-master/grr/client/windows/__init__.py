#!/usr/bin/env python
"""This module contains windows specific client code."""


# These need to register plugins so, pylint: disable=unused-import
from grr.client.windows import installers
from grr.client.windows import regconfig
