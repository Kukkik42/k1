#!/usr/bin/env python
"""This module contains linux specific client code."""


# These need to register plugins so, pylint: disable=unused-import
