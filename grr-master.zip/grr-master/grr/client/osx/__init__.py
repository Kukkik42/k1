#!/usr/bin/env python
"""This module contains os specific client code."""

# These need to register plugins so, pylint: disable=unused-import
from grr.client.osx import installers
