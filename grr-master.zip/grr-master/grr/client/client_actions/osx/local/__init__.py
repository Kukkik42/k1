#!/usr/bin/env python
"""A module to load the local MacOS client plugins."""

