#!/usr/bin/env python
"""All the test files for report plugins are imported here."""

# These need to register plugins so, pylint: disable=unused-import
from grr.gui.api_plugins.report_plugins import report_plugins_test
