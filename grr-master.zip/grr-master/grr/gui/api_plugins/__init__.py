#!/usr/bin/env python
"""GRR restful API rendering plugins."""
