#!/usr/bin/env python
"""This file just contains the werkzeug http routing map."""

from werkzeug import routing

HTTP_ROUTING_MAP = routing.Map()
