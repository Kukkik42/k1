Building all infra images:

```bash
# run from project root
infra/base-images/all.sh
```
