#!/bin/bash -eu

$SRC/libreoffice/bin/oss-fuzz-build.sh
