const a = 1;
const b = 2;

export default () => a + b;