require('./index.scss');

module.exports = function () {
  return 2;
};
