const url = require('./test.txt');

export function getRaw() {
  return url;
}