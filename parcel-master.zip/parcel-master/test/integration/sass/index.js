require('./index.sass');

module.exports = function () {
  return 2;
};
