require('./index.styl');

module.exports = function () {
  return 2;
};
