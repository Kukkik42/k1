module.exports = {
  paths: [__dirname + '/deps']
};
