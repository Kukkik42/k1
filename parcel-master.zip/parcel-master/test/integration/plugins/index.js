module.exports = require('./test.txt');
