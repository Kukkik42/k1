require('./index.less');

module.exports = function () {
  return 2;
};
