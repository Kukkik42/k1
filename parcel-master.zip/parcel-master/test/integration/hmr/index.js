var local = require('./local');

function run() {
  output(local.a + local.b);
}

run();
