var map = require('./index.css');

module.exports = function () {
  return map.index;
};
