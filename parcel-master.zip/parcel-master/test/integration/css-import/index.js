require('./index.css');

module.exports = function () {
  return 2;
};
