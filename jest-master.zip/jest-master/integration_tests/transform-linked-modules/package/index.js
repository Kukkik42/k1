module.exports = 'package/index';
