module.exports = 'ignored/normal';
