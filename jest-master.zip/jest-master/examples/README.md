## How to run the examples:

#### 1. Install jest

```
npm install
```

#### 2. Move to example

```
cd examples/jquery
```

#### 3. Install example

```
npm install
```

#### 4. Run example

```
npm test
```
