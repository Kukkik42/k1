class X {
  render(): ?ReactNode {
    return null;
  }
}
