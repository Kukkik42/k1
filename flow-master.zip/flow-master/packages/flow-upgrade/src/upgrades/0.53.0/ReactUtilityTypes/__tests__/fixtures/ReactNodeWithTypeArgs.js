class X {
  render(): ?React$Node<any> {
    return null;
  }
}
