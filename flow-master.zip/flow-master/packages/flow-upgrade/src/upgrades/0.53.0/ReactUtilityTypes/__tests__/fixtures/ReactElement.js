(any: React$Element<Config>);
(any: React$Element<Props>);
(any: React$Element<any>);
(any: React$Element<mixed>);
(any: React$Element<*>);
(any: React$Element<>);
(any: React$Element);

(any: ReactElement<Config>);
(any: ReactElement<Props>);
(any: ReactElement<any>);
(any: ReactElement<mixed>);
(any: ReactElement<*>);
(any: ReactElement<>);
(any: ReactElement);

(any: React.Element<Config>);
(any: React.Element<Props>);
(any: React.Element<any>);
(any: React.Element<mixed>);
(any: React.Element<*>);
(any: React.Element<>);
(any: React.Element);

(any: Element<Config>);
(any: Element<Props>);
(any: Element<any>);
(any: Element<mixed>);
(any: Element<*>);
(any: Element<>);
(any: Element);
