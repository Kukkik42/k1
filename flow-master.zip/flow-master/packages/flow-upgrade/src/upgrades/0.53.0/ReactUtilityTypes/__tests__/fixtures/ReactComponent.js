(any: React$Component<DefaultProps, Props, State>);
(any: ReactComponent<DefaultProps, Props, State>);
(any: Component<DefaultProps, Props, State>);
(any: React.Component<DefaultProps, Props, State>);

// Should leave these alone.
(any: React$Component<Props>);
(any: React$Component<Props, State>);
