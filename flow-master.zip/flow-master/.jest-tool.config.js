module.exports = {
  rootDir: 'tsrc',
  testEnvironment: 'node'
}
