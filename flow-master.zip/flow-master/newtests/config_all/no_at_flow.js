var x: number = "not a number";
