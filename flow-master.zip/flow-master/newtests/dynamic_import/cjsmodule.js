// @flow

module.exports = {
  pi: 3.14
};
