// @flow

export type T1 = number;
export type T2<U, V> = Array<U>;
