// @noflow
var x: string = 123;
