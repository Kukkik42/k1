// @flow
var x: string = 123;
