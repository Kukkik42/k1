export default 123;

var dependencyError: string = 123;
