require('./cycleA');

var x: string = 123;
