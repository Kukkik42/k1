import dependency from './dependency';

var focusedError: string = 123;

export default 'hello';
