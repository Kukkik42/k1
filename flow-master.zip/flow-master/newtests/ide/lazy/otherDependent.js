import dependency from './dependency';

var otherDependentError: string = 123;
