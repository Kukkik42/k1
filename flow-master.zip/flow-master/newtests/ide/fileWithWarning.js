// flowlint sketchy-null:warn
var x: ?boolean = true;
if (x) {
}
