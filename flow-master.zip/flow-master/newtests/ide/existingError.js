var existingError: number = true;
