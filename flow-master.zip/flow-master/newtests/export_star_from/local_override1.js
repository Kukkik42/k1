// @flow

export const C = "asdf";
export * from "./origin";
