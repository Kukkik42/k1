// @flow

export * from "./origin";
export const C = "asdf";
