// @flow

export const C = 42;
