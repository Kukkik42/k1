/*  */

function foo(o: Object) {
  o.
}
