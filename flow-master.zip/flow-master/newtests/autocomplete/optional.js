//

function foo(obj: { x?: string, f: (x?: string) => void, o: { x?: string } }) {
  return obj.
}
