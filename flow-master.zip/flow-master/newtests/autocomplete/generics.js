//

class C<X> { }

function foo(o: { cn: C<number> }) {
  o.
}
