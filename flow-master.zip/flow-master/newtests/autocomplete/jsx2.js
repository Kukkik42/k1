//

var React = require('react');

class C extends React.Component {
  props: { x: number, y: string };
}
<C x = 0,  // Comment here so the space after , doesn't get trimmed
