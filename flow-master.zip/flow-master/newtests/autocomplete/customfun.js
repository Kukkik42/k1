//

declare var idx: $Facebookism$Idx;
declare var merge: $Facebookism$Merge;
declare var mergeDeepInto: $Facebookism$MergeDeepInto;
declare var mergeInto: $Facebookism$MergeInto;
declare var mixin: $Facebookism$Mixin;
declare var objectGetPrototypeOf: Object$GetPrototypeOf
declare var objectAssign: Object$Assign

m
