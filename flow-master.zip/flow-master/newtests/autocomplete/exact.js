/**
 *
 */

declare var obj: {| num: number, str: string |};

obj.
