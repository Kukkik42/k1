/*  */

// issue #1197
class Foo {
  baz: string;
  bar(): void {}
  hello(): void {
    this.
  }
}
