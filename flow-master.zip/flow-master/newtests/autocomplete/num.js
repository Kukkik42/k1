//

var num = 123;
num.
