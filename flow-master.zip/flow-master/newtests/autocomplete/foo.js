/**
 *
 */

var obj = {
  num: 123,
  str: 'hello',
};

obj.
