export const aNum = 42;
export type aType = string;
