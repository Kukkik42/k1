
export type * from "./origin";
