export type * from "./origin";
export type aType = number;
