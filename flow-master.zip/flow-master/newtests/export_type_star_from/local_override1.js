export type aType = number;
export type * from "./origin";
