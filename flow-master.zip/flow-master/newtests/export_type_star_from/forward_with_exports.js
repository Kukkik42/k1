export type middleType = number;
export const middleString = "asdf";
export type * from "./origin";
