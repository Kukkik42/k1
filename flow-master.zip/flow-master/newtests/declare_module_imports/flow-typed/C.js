declare module "C" {
  import type {DT} from "D";
  declare export type CT = {D: DT};
}
