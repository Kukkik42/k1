declare module "D" {
  import type {CT} from "C";
  declare export type DT = {C: CT};
}
