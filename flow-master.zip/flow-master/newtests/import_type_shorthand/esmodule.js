// @flow

export type T = number;
export class C {};
