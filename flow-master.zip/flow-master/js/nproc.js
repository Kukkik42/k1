//Provides: nproc const
function nproc() {
  return 1;
}
