//Provides: caml_xx_digest
function caml_xx_digest() {
  return "";
}

//Provides: caml_xx_init
function caml_xx_init() {
  return null;
}

//Provides: caml_xx_update
function caml_xx_update() {
  return;
}

//Provides: caml_xx_update_int
function caml_xx_update_int() {
  return;
}
