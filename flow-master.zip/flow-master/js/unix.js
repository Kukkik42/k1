//Provides: unix_getpid const
function unix_getpid() {
  return 0;
}

//Provides: unix_isatty const
function unix_isatty() {
  return false;
}
