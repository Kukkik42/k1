//Provides: hh_realpath
function hh_realpath(path) {
  // Stub implementation that does nothing. Ideally we'd avoid calling this
  // (via `Path.make`) completely.
  return 0; // `None`
}
