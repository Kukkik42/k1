/* @flow */

function foo(x: string, y: number): string {
  return x.length * y;
}

foo("Hello", 42);
