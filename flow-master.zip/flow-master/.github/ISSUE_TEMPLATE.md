If this is a bug, please try reproducing using https://flow.org/try/.
