export function getSHA(): string
