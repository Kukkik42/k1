export function getReplacements(): {}
export function getCLICommands(): string[]
