const appInfo = require('../../../app/app-info')

global.__CLI_COMMANDS__ = appInfo.getCLICommands()
