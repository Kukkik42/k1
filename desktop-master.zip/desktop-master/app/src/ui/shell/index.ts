export { ShellError } from './shell-error'
