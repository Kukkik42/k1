/**
 * The area in pixels either side of the right-edge of the diff gutter to
 * detect when a group of lines should be highlighted, instead of a single line.
 */
export const RangeSelectionSizePixels = 10
