export { Octicon } from './octicon'
export { OcticonSymbol } from './octicons.generated'
export { iconForRepository } from './repository'
