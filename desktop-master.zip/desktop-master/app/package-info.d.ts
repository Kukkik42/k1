export function getProductName(): string
export function getCompanyName(): string
export function getVersion(): string
export function getBundleID(): string
