#!/bin/sh
exec /usr/local/bin/healthd
