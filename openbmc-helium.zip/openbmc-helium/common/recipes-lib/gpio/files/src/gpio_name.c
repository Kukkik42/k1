#include <stdlib.h>

int
gpio_num(char *str)
{
  return -1;
}

char *
gpio_name(int gpio, char *str)
{
  return NULL;
}

